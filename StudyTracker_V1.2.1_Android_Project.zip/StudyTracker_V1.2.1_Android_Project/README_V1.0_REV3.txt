Study Tracker V1.0 - Revision 3

Updates:
- Home screen contains the Analysis entry point; removed Analytics from the DU/BUET tracker page.
- Analysis opens a DU / BUET chooser, then displays separate institution-specific metrics and subject progress.
- DU and BUET home/analysis cards are wired for bundled institutional logo assets (du_official.png and buet_official.png). If these files are not present, the UI falls back to DU / BUET monograms.
- All app logos, including the hibiscus option, render inside the same theme-colored rounded-square logo tile.

Official logo references identified:
- BUET seal/logo files: https://eee.buet.ac.bd/outreach/branding
- University of Dhaka emblem shown in official DU documents: https://apa.du.ac.bd/apa_file/1755427467.pdf

Important build note:
This project contains the Android Studio source. An installable APK was not compiled in this environment because Android SDK / Gradle build tools are not installed. For a complete offline build, add the official image files as:
  app/src/main/assets/du_official.png
  app/src/main/assets/buet_official.png
Then open the project in Android Studio and Build > Build APK(s).

Version: 1.0
Application ID: com.shadhin.studytracker
