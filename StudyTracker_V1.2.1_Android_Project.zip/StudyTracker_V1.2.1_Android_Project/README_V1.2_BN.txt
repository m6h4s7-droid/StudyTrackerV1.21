Study Tracker V1.2 — Android Studio Project

নতুন পরিবর্তন:
- Admission Info কার্ড ছোট করা হয়েছে; 360×800 CSS viewport-এ ৩টি সম্পূর্ণ কার্ড একসঙ্গে দেখা যায়।
- আবেদন ফি ও আবেদন সময়ের কাউন্টডাউন একই সারিতে। পরীক্ষার কাউন্টডাউন আলাদা শিরোনামসহ বক্সে।
- ইংরেজি ফি: 1000 Tk; বাংলা ফি: ১০০০ টাকা।
- আবেদন করেছি/করিনি স্ট্যাটাস Edit করার পরও বজায় থাকে।
- বাংলা ১০টি (Li Ador Noirrit-এর বদলে Google Fonts-এর Noto Sans Bengali UI) এবং English ১০টি font family, সঙ্গে প্রতিটি ভাষায় System Default। English তালিকায় Roboto-এর বদলে Galada।
- Font selection app state-এ সেভ হয় এবং Backup/Restore-এ অন্তর্ভুক্ত।

ফন্ট নোট:
২০টি ফন্ট Google Fonts থেকে লোড হয়। প্রথমবার custom font ব্যবহার করতে ইন্টারনেট লাগবে। বাকি Study Tracker ফিচার offline-এও কাজ করে; custom font আগে লোড না হয়ে থাকলে offline অবস্থায় system fallback দেখা যাবে।

Build:
Android Studio-তে এই project folder Open করো, Gradle Sync করো, তারপর Build > Build APK(s)।
Application ID: com.shadhin.studytracker
Version: 1.2 (versionCode 2)


সর্বশেষ আপডেট: V1.2.1 — Admission Applied? checkbox, fee formatting, AM/PM, 4-column/12-font picker এবং ভাষা-নির্ভর UI আপডেট।
