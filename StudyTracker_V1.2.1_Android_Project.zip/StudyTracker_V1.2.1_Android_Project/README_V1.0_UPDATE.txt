Study Tracker Version 1.0 — latest UI revision

Changes in this revision:
- Removed Settings shortcut from DU/BUET study tracker pages.
- Removed Biology present/absent subtitle from tracker pages.
- Updated Ruby Gold to Hibiscus Red: red is the primary accent with gold, black and white supporting colors.
- Hibiscus logo now appears inside the same rounded gradient tile as the other app logos.

Open this project in Android Studio, sync Gradle, then Build > Build APK(s). Keep the same application ID and signing key for in-place updates.
