Study Tracker — Android Studio Project
Creator: Mehedi Hasan Shadhin

এই ফোল্ডারটি Android Studio-তে Open করে Gradle Sync সম্পন্ন করুন। এরপর:
Build > Build Bundle(s) / APK(s) > Build APK(s)

APK output সাধারণত app/build/outputs/apk/debug/app-debug.apk

অ্যাপটি WebView-ভিত্তিক Offline Android wrapper। কোনো INTERNET permission নেই। HTML/CSS/JS অ্যাপের assets-এ bundled, তাই নেট ছাড়াই চলে। WebView DOM storage/localStorage-এ progress, streak, badges, theme ও settings থাকে।

Backup: Downloads/Study Tracker/study-tracker-backup.json
Restore: Settings বা Home-এর Restore থেকে JSON নির্বাচন করুন।

Syllabus: প্রদত্ত HSC Science Chapter Tracker ফাইলের Physics, Chemistry, Higher Math ও Biology chapter list ব্যবহার করা হয়েছে। DU-তে Biology আছে; BUET-এ নেই। এটি অধ্যায়-ট্র্যাকার, অফিসিয়াল ভর্তি বিজ্ঞপ্তি/পূর্ণাঙ্গ প্রশ্নসিলেবাস নয়। ভর্তি পরীক্ষার সেশনভেদে সিলেবাস বদলালে chapter list আপডেট করা প্রয়োজন হতে পারে।
